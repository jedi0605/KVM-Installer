
__version__ = "0.600.1"
__version_info__ = tuple([ int(num) for num in __version__.split('.')])
rhel6defaults = bool(0)
